import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string) {
  return new Date(date).toLocaleDateString("ru-RU", {
    day: "numeric", month: "short", year: "numeric",
  });
}

export function formatDateShort(date: string) {
  return new Date(date).toLocaleDateString("ru-RU", {
    day: "numeric", month: "short",
  });
}
